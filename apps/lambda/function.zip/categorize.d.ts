export declare function categorizeMerchant(merchantName: string): string;
