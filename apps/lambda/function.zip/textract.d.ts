interface ExtractedData {
    merchant: string | null;
    totalAmount: number | null;
    receiptDate: Date | null;
    lineItems: Array<{
        description: string;
        amount: number | null;
    }>;
    rawResponse: any;
}
export declare function analyzeReceipt(bucket: string, key: string): Promise<ExtractedData>;
export {};
