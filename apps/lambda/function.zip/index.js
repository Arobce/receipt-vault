"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.handler = handler;
const client_1 = require("@prisma/client");
const adapter_pg_1 = require("@prisma/adapter-pg");
const textract_1 = require("./textract");
const categorize_1 = require("./categorize");
const adapter = new adapter_pg_1.PrismaPg({ connectionString: process.env.DATABASE_URL });
const prisma = new client_1.PrismaClient({ adapter });
async function handler(event) {
    for (const record of event.Records) {
        const bucket = record.s3.bucket.name;
        const key = decodeURIComponent(record.s3.object.key.replace(/\+/g, " "));
        // Extract receipt ID from key: uploads/{userId}/{uuid}.ext
        const receipt = await prisma.receipt.findFirst({
            where: { s3Key: key },
        });
        if (!receipt) {
            console.error(`No receipt found for S3 key: ${key}`);
            continue;
        }
        try {
            await prisma.receipt.update({
                where: { id: receipt.id },
                data: { status: "PROCESSING" },
            });
            const extracted = await (0, textract_1.analyzeReceipt)(bucket, key);
            let categoryId = null;
            if (extracted.merchant) {
                const categoryName = (0, categorize_1.categorizeMerchant)(extracted.merchant);
                const category = await prisma.category.findUnique({
                    where: { name: categoryName },
                });
                if (category)
                    categoryId = category.id;
            }
            await prisma.receipt.update({
                where: { id: receipt.id },
                data: {
                    merchant: extracted.merchant,
                    totalAmount: extracted.totalAmount,
                    receiptDate: extracted.receiptDate,
                    lineItems: extracted.lineItems,
                    rawTextract: extracted.rawResponse,
                    categoryId,
                    status: "PROCESSED",
                },
            });
            console.log(`Processed receipt ${receipt.id}: ${extracted.merchant} - $${extracted.totalAmount}`);
        }
        catch (error) {
            console.error(`Failed to process receipt ${receipt.id}:`, error);
            await prisma.receipt.update({
                where: { id: receipt.id },
                data: { status: "FAILED" },
            });
        }
    }
}
//# sourceMappingURL=index.js.map