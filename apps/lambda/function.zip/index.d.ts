import { S3Event } from "aws-lambda";
export declare function handler(event: S3Event): Promise<void>;
