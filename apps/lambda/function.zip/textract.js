"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.analyzeReceipt = analyzeReceipt;
const client_textract_1 = require("@aws-sdk/client-textract");
const textract = new client_textract_1.TextractClient({ region: process.env.AWS_REGION || "us-east-1" });
function findField(fields, targetType) {
    for (const field of fields) {
        const fieldType = field.Type?.Text;
        if (fieldType === targetType && field.ValueDetection?.Text) {
            return field.ValueDetection.Text;
        }
    }
    return null;
}
function parseAmount(text) {
    const cleaned = text.replace(/[^0-9.,]/g, "").replace(/,/g, "");
    const num = parseFloat(cleaned);
    return isNaN(num) ? null : num;
}
function parseDate(text) {
    const date = new Date(text);
    return isNaN(date.getTime()) ? null : date;
}
async function analyzeReceipt(bucket, key) {
    const command = new client_textract_1.AnalyzeExpenseCommand({
        Document: {
            S3Object: { Bucket: bucket, Name: key },
        },
    });
    const response = await textract.send(command);
    const documents = response.ExpenseDocuments || [];
    let merchant = null;
    let totalAmount = null;
    let receiptDate = null;
    const lineItems = [];
    for (const doc of documents) {
        const summaryFields = doc.SummaryFields || [];
        const vendorName = findField(summaryFields, "VENDOR_NAME");
        if (vendorName && !merchant)
            merchant = vendorName;
        const total = findField(summaryFields, "TOTAL");
        if (total && totalAmount === null)
            totalAmount = parseAmount(total);
        const dateStr = findField(summaryFields, "INVOICE_RECEIPT_DATE");
        if (dateStr && !receiptDate)
            receiptDate = parseDate(dateStr);
        for (const group of doc.LineItemGroups || []) {
            for (const item of group.LineItems || []) {
                const fields = item.LineItemExpenseFields || [];
                const desc = findField(fields, "ITEM") || findField(fields, "PRODUCT_CODE") || "";
                const price = findField(fields, "PRICE");
                if (desc) {
                    lineItems.push({
                        description: desc,
                        amount: price ? parseAmount(price) : null,
                    });
                }
            }
        }
    }
    return {
        merchant,
        totalAmount,
        receiptDate,
        lineItems,
        rawResponse: response,
    };
}
//# sourceMappingURL=textract.js.map